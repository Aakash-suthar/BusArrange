<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <title>Welcome to CodeIgniter</title>
    </head>

    <body>
    <div class="container">
    <div style="height:100px" class="container"><h1 style="margin-top:30px;">Register Form</h1></div>
    <?php echo form_open('ajax-form-validation/post');?> 
    <div class="row">
    <div class="col-6">
    <div class="form-group">
            <label for="Firstname">FirstName :</label>
            <input type="text" class="form-control" name ="firstname" id="Firstname" placeholder="Enter FirstName">
        </div>
    </div>
    <div class="col-6">
    <div class="form-group">
                <label for="LastName">LastName :</label>
                <input type="text" class="form-control" name ="lastname" id="LastName" placeholder="Enter LastName">
            </div>
    </div>
    </div>
 
      
           
        <div class="form-group">
            <label for="exampleInputEmail1">Email Address</label>
            <input type="email" name ="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
            <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
        </div>
        <div class="form-group">
                    <label for="ContactNo">Contact No :</label>
                    <input type="number" class="form-control" name ="contactno"  id="ContactNo" placeholder="Enter Contact Number">
                </div>
        <div class="form-group">
            <label for="exampleInputPassword1">Password</label>
            <input type="password" name ="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
        </div>
        <button type="submit" class="btn btn-primary btn-submit">Submit</button>
        <button type="button" style="margin-left:50px;" class="btn btn-success getdata">Get Data</button>
    </form>
    <div class="container newtable" style="margin-top:50px" id="resulttable">

    </div>
</div>
    </body>


    <script type="text/javascript">

        $(document).ready(function() {
     
            $(".getdata").click(function(e){
               
                e.preventDefault();
                $("#resulttable").empty();
                $.ajax({
                  url:"/home/getalldata",
                  type:"POST",
                  success: function(data) {
                      var data2 = JSON.parse(data);
                      var a = "";
                      for (i = 0; i < data2.length; i++) {
                            var arrayItem =  data2[i];
                            a += ("<tr>" +
                                "<td>" + arrayItem["firstname"] + "</td>" +
                                "<td>" +arrayItem["lastname"] + "</td>" +
                                "<td>" +arrayItem["email"] + "</td> " +
                                "<td>" +arrayItem["phoneno"] + "</td> " +
                                "<td>" + arrayItem["password"] + "</td> " +
                                "</tr>");
                        }
                    $('<table class="table table-bordered">').html(
                            "<thead> " +
                            "<tr>" +
                            "<th> <strong> FirstName</strong>  </th>" +
                            "<th> <strong> Lastname </strong></th> " +
                            "<th> <strong> Email </strong></th>" +
                            "<th> <strong> Phone No </strong></th>" +
                            "<th> <strong> Password </strong></th>" +
                            "</r> </thead>" +
                            " <tbody>" +
                            a
                            +
                            "</tbody>" +
                            "</table>"
                            ).appendTo('#resulttable');
                    }

                });
            });


          $(".btn-submit").click(function(e){
        
              e.preventDefault();
        
              var firstname = $("input[name='firstname']").val();  
              var lastname = $("input[name='lastname']").val(); 
              var contactno = $("input[name='contactno']").val();    
              var password = $("input[name='password']").val();  
              var email = $("input[name='email']").val();
              $.ajax({
        
                  url: $(this).closest('form').attr('action'),
                  type:$(this).closest('form').attr('method'),
                  dataType: "json",
        
                  data: {firstname:firstname, lastname:lastname,contactno:contactno,password:password, email:email},
   
                  success: function(data) {
        
                      if($.isEmptyObject(data.error)){
        
                        alert(data.success);
                        $(".getdata").click();
                      }else{
                        alert(data.error);
       
                      }
        
                  }
        
              });
        
          }); 
        
        });
        
        </script>

</html>