<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {


	public function __construct() {

		parent::__construct(); 
		header('Access-Control-Allow-Origin: *');
		header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
		$this->load->database();
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->helper('email');
		$this->load->model('User');
  
	 }
	
	public function index()
	{
		// $query=$this->db->query("select * FROM user");
		// $results = $query->result();
		
		// foreach ($results as $row)
		// {
		// 		echo $row->id;
		// 		echo $row->firstname;
		// 		echo $row->lastname;
		// }
			
		$this->load->view('Register');
	}

	public function getalldata()
	{
		$data = $this->User->getdata();
		echo json_encode($data);
	}


	public function validationForm()

	{
 
		$this->form_validation->set_rules('firstname', 'firstname', 'required|alpha');
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email');
		$this->form_validation->set_rules('contactno', 'contactno', 'required|regex_match[/^[0-9]{10}$/]');
		$this->form_validation->set_rules('password', 'password', 'required|regex_match[/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/]');
		$this->form_validation->set_rules('lastname', 'lastname', 'required|alpha');

		 $data = $this->input->post();
		 $firstname = $data['firstname'];
		 $lastname = $data['lastname'];
		 $phoneno = $data['contactno'];
		 $password = $data['password'];
		 $email = $data['email'];
		 if ($this->form_validation->run() == FALSE){
 
			 $errors = validation_errors();
 
			 echo json_encode(['error'=>$errors]);
 
		 }
		 else{
			 if ($this->User->insert($firstname,$lastname,$email,$phoneno,$password)){
				echo json_encode(['success'=>'success']);

			 }
			else{
				echo json_encode(['Failes'=>'Database error.']);
			}
			
 
		 }
 
	 }
}
