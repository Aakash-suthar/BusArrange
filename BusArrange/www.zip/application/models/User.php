<?php

class User extends CI_Model {

    function __construct()
    {
        parent::__construct();
        
    }


    function getdata()
	{
        $this->load->database();
     	$query=$this->db->query("select * FROM user");
	    $results = $query->result();
        return $results;
    }
    
    function insert($firstname,$lastname,$email,$phoneno,$password)
	{
        $this->load->database();
        $data = array(
			'firstname' => $firstname,
			'lastname' =>$lastname,
			'email' => $email,
			'phoneno' => $phoneno,
			'password' => $password,
	    );
       $this->db->insert('user', $data);
       return true;
	}
}

?>